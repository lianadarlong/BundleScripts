import os
import re
import pyUtils

skippedAbruptly = {}

def findFuntionCallContent( functionName, pageContent ):
	contentList = []
	bCount = -1
	cCount = 0
	occurrences =  list(find_all(pageContent, functionName))
	for i in occurrences:
		content = ""
		bCount = -1
		cCount = 0
		tempStr = pageContent[i+len(functionName):len(pageContent)]
		if tempStr[0] == "(":
			for charecter in tempStr:
				if charecter == "(":
					bCount = bCount + 1
				if charecter == ")" and bCount == 0:
					content = tempStr[:cCount+1]
					break
				if charecter == ")" and bCount != 0:
					bCount = bCount - 1
				cCount = cCount + 1
		if content != "":
			contentList.append(content)
	return contentList
	
def find_all(a_str, sub):
    start = 0
    while True:
        start = a_str.find(sub, start)
        if start == -1: return
        yield start
        start += len(sub) # use start += 1 to find overlapping matches
		
def isSafeFunction(line, param):
	#Update any safe functions, which can validate/does not take the actual value of/output encode the strings passed to it 
	safeFunctions = ["equals","equalsIgnoreCase","isEmpty","exist","Code.encodeSpecial","BigInteger","parseInt","parseBoolean","Integer","Boolean.valueOf","parseDouble",]
	safeFunctionsWithParameters = ["Code.textLink","Code.hiddenVar","Code.bold","Code.imageLink","Code.inputText","Code.modernButton","Code.modernScriptButtonEscaped"]
	for sf in safeFunctions:
		if re.findall(r"" + sf + r"[\s\n]*\([\w\+\s\n]*"+ re.escape(param) + r"[\w\+\s\n]*\)[\s\n]*", line) != []:
			return 1
	for sf in safeFunctionsWithParameters:
		if re.findall(r"" + sf + r"[\s\n]*\(.*"+ re.escape(param) + r".*\)*", line) != []:
			return 1
	return 0

def findPossibleXSS(directory, outDirectory):
	global skippedAbruptly
	issue_count = 0
	userInputFunctions = ["getParameter","getValidParameter","getValidUrlParameter","getRequestParameter","getParameterByName","getParameterValues"]  # Update any new functions/calls here, which gets user inputs
	writers = ["out.println","out.print","wrapIn"]    #  Update any new writers here, which prints variables/strings to user 
	pyUtils.writeToCSV(["Issue Count","File Path","Sink Function","Source call","Source Variable","Printed In"],outDirectory+"/xss_"+outDirectory+".csv")
	for root, subdirs, files in os.walk(directory):
		for file in os.listdir(root):
			filePath = os.path.join(root, file)
			if os.path.isdir(filePath):
				pass
			else:
				try:
					if filePath[-3:] == "jsp" or filePath[-4:] == "java" or filePath[-3:] == "inc":    # Update any new file extensions here 
						content_file = open(filePath, 'r', encoding ="utf8", errors="replace")
						fileContent = content_file.read()
						print("[i] Finding possible XSS in " + filePath)
						for userInputFunction in userInputFunctions:
							userInputLines = re.findall(r"\w+[ \s]*=[ \s\w().]*" + userInputFunction + r"[ \s]*\(.*\)",fileContent)
							source_list = []
							for r in userInputLines:
								try:
									source = (r.split()[0] , r)
								except:
									source = (r.split("=")[0], r)
								tempAray = re.findall(r"[\w.]*" + userInputFunction + r"[ \s]*\([\w\s.\"\']*\)",r)
								try:
									if isSafeFunction(r, tempAray[0]) != 1:
										source_list.append(source)	
								except:
									source_list.append(source)
							for s in source_list:
								for writer in writers:
									pSinks = findFuntionCallContent( writer, fileContent)
									for ps in pSinks:
										if list(find_all(ps,s[0].strip())) != []:    # search for variables with user input in output strings  
											if re.findall(r"[ \s\n]*\+[ \s\n]*"+ s[0].strip() + r"[ \s\n]*\+[ \s\n]*",ps) != [] or  re.findall(r"[ \s\n]*\([ \s\n]*"+ s[0].strip() + r"[ \s\n]*\)[ \s\n]*",ps) != []:
												if isSafeFunction(ps, s[0].strip()) != 1:
													issue_count = issue_count + 1
													print("[i] XSS: Count - " + str(issue_count) + " ~~~ Source call at: " + s[1] + "\nPrinted In \n|" + ps + "|\n")
													pyUtils.writeToCSV([issue_count,filePath,writer,s[1],s[0],ps],outDirectory+"/xss_"+outDirectory+".csv")
							# Search direct print of user inputs in output writers 
							for writer in writers:
								pSinks = findFuntionCallContent( writer, fileContent)
								for ps in pSinks:
									userInputFunctionCalls = re.findall(r"[\w.]*" + userInputFunction + r"[ \s]*\([\w\s.\"\']*\)",ps)
									for userInputFunctionCall in userInputFunctionCalls:
										if isSafeFunction(ps, userInputFunctionCall) != 1:
											issue_count = issue_count + 1
											print("[i] XSS: Count - " + str(issue_count) + " ~~~ Source call at: Inline Call using " + userInputFunction + "()\nPrinted In \n|" + ps + "|\n")
											pyUtils.writeToCSV([issue_count,filePath,writer,userInputFunction+"()","inline",ps],outDirectory+"/xss_"+outDirectory+".csv")
							# Search direct print in JSPS - ex: <%= request.getParameter("object")%>
							JSPDirectPrints = re.findall(r'<%=.*' + userInputFunction + r'[ \s]*\([\w\s.\"\']*\)%>',fileContent)
							for JSPDirectPrint in JSPDirectPrints:
								userInputFunctionCalls = re.findall(r"[\w.]*" + userInputFunction + r"[ \s]*\([\w\s.\"\']*\)",JSPDirectPrint)
								for userInputFunctionCall in userInputFunctionCalls:
									if isSafeFunction(JSPDirectPrint, userInputFunctionCall) != 1:
										issue_count = issue_count + 1
										print("[i] XSS: Count - " + str(issue_count) + " ~~~ Source call at: Inline JSP Call using " + userInputFunction + "()\nPrinted In \n|" + JSPDirectPrint + "|\n")
										pyUtils.writeToCSV([issue_count,filePath,"inline JSP",userInputFunction+"()","inline",JSPDirectPrint],outDirectory+"/xss_"+outDirectory+".csv")
						content_file.close() 
				except KeyboardInterrupt:
					key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
					if key_choice.lower() == 'c':
						skippedAbruptly["findPossibleXSS "+filePath] = "KeyboardInterrupt - skipped file"
						pass
					elif key_choice.lower() == 's':
						skippedAbruptly["findPossibleXSS "+filePath] = "KeyboardInterrupt - skipped analysis"
						return skippedAbruptly
					elif key_choice.lower() == 'q':
						skippedAbruptly["findPossibleXSS "+filePath] = "KeyboardInterrupt - quit scan"
						raise
					else:
						skippedAbruptly["findPossibleXSS "+filePath] = "KeyboardInterrupt - skipped file"
						pass
				except Exception as e:
					print(("[X] findPossibleXSS: Some error occurred: "+ filePath))
					skippedAbruptly["findPossibleXSS "+filePath] = str(e)
	print("===============================")
	print("[i] XSS Scan finished. Total " + str(issue_count) + " issues found!")
	print("===============================")
	return skippedAbruptly

if __name__ == "__main__":
	directory = input("Enter path to directory: \n> ")
	findPossibleXSS(directory, ".")