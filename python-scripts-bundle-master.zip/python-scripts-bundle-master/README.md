These are collection of scripts to perform semi-automated utility or scanning for AppSec tasks. 

# Usage
There are two ways to use these scripts. 

1. With no pre-requisites 

Use .exe (Windows) or .sh (Linux/MacOS) in executable folder. 
Copy to local machine and execute it in command line to get all script options 
You can also add folder path of copied binary to PATH environment variable and use the tool anywhere using `pyScriptBundle` command. 

2. With python environment 

Python 3 environment is required. 

Download whole folder and open folder in command line. 

`python start.py` - to use whole tool with options (same as using binaries)

`python pyFindPossibleXSS.py` - to use individual scripts, which should be asking further input like paths to scan 

Output of these scirpts are .csv files, saved in same folder when used single script and saved inside a folder named out_TIMESTAMP in folder from where binary is executed. 

# Screenshot

![Alt-Text](https://git.netcracker.com/DEMO.ACG/python-scripts-bundle/-/raw/master/Screenshot.PNG)

# Individual scripts description 

Script name / option | Usage description | Individual script usage
----|----|----
pyWebrootTracker.py <br />(Option 1 and 2) | This script can be used to track same source's changes in code n new verison. Use option 1 to create a DB with code details and use option two to latest code and provide old db to compare. | to create <br />`python pyWebrootTracker.py CREATE /path/to/web-root/` <br /> to compare <br />`python pyWebrootTracker.py COMPARE /path/to/web-root/ previous_jspDB_FILE.db`
pySensitiveInfos.py <br />(Option 3) | This script can be used to find hard-coded or vulnerable sensitive info from source code | `python pySensitiveInfos.py` and enter path to source code
pyRiskyWords.py <br />(Option 4) | This script finds risky, profane, inappropriate words in source code | `python pyRiskyWords.py` and enter path to source code
pyFindPossibleXSS.py<br />(Option 5)| This is to identify data source and sinks in TOMS code for XSS vulnerability. Use to identify TOMS custom input functions. | `python pyFindPossibleXSS.py` and enter path to source code
pyFindPossibleSQLi.py<br />(Option 6)| This is to identify data source and sinks in TOMS code for SQL Injection vulnerability. Use to identify TOMS custom input functions. | `python pyFindPossibleSQLi.py` and enter path to source code
pyFindPossibleRedirect.py<br />(Option 7)| This is to identify data source and sinks in TOMS code for Open Redirect vulnerability. Use to identify TOMS custom input functions. | `python pyFindPossibleRedirect.py` and enter path to source code
pyFindPathAndExtensions.py<br />(Option 8)| This option lists all file types in source code and an excel with paths of file which can be sorted in excel based on extension| `python pyFindPathAndExtensions.py` and enter path to source code
pyFindPossibleBackdoor.py<br />(Option 8)| This is to identify data source and sinks in TOMS code for command injection vulnerability. Use to identify TOMS custom input functions.| `python pyFindPossibleBackdoor.py` and enter path to source code
search_remove_all_comments_2.3.py<br />(Not packaged in binary)<br />**User discretion:**<br />*this script makes changes to source files.* <br /> *i.e, removal of comments* | To clean source code from comments. Used in ESP tasks. | `python search_remove_all_comments_XX.X.py "/path/to/directory"`
signing_tool_1.2.py<br />(Not packaged in binary)<br >**User discretion:**<br /> *this script makes changes to source files,* <br />*i.e, add copyright comment at start*| Use to add copyright comment to the start of every source files. | `python signing_tool_X.X.py /path/to/source "Copyright comment to be added"`


# To build/Package scripts yourselves to create binaries 
`pyinstaller –F --clean --icon="favicon.ico" --name="pyScriptBundle" start.py`
