import os
import re 
import pyUtils

skippedAbruptly = {}

def findFuntionCallContent( functionName, pageContent ):
	contentList = []
	bCount = -1
	cCount = 0
	occurrences =  list(find_all(pageContent, functionName))
	for i in occurrences:
		content = ""
		bCount = -1
		cCount = 0
		tempStr = pageContent[i+len(functionName):len(pageContent)]
		if tempStr[0] == "(":
			for charecter in tempStr:
				if charecter == "(":
					bCount = bCount + 1
				if charecter == ")" and bCount == 0:
					content = tempStr[:cCount+1]
					break
				if charecter == ")" and bCount != 0:
					bCount = bCount - 1
				cCount = cCount + 1
		if content != "":
			contentList.append(content)
	return contentList
	
def find_all(a_str, sub):
    start = 0
    while True:
        start = a_str.find(sub, start)
        if start == -1: return
        yield start
        start += len(sub) # use start += 1 to find overlapping matches

def findPossibleRedirect(directory, outDirectory):
	global skippedAbruptly
	issue_count = 0
	pyUtils.writeToCSV(["Count","File","Sink Function","Source call","Source Variable","Printed In"],outDirectory+"/redirect_"+outDirectory+".csv")
	for root, subdirs, files in os.walk(directory):
		for file in os.listdir(root):
			filePath = os.path.join(root, file)
			if os.path.isdir(filePath):
				pass
			else:
				try:
					if filePath[-4:] == "java" or filePath[-3:] == "jsp" or filePath[-3:] == "inc":
						content_file = open(filePath, 'r', encoding ="utf8", errors="replace")
						fileContent = content_file.read()
						r1 = re.findall(r"\w+[ \t]*=[ \t\w().]*getParameter\(.*\)",fileContent)
						r2 = re.findall(r"\w+[ \t]*=[ \t\w().]*getValidParameter\(.*\)",fileContent)
						source_list = []
						print("[i] Finding possible redirect in " + filePath)
						for r in r1:
							try:
								source = (r.split()[0] , r)
							except:
								source = (r.split("=")[0], r)
							source_list.append(source)	
						writers = ["sendRedirect","RedirectException"]
						for s in source_list:
							for writer in writers:
								pSinks = findFuntionCallContent( writer, fileContent)
								for ps in pSinks:
									if list(find_all(ps,s[0].strip())) != []:
										if re.findall(r"[ \t\n]*\+[ \t\n]*"+ s[0].strip() +"[ \t\n]*\+[ \t\n]*",ps) != [] or  re.findall(r"[ \t\n]*\([ \t\n]*"+ s[0].strip() +"[ \t\n]*\)[ \t\n]*",ps) != []:
											issue_count = issue_count + 1
											print("[i] Open Redirect issue count: " + str(issue_count))
											print("Sink Function: " + writer )
											print("Source call: "+s[1])
											print("Source Variable:  |" + s[0] + "|\nPrinted In \n|" + ps + "|\n")
											listOfColumns = []
											listOfColumns.append(str(issue_count))
											listOfColumns.append(str(filePath))
											listOfColumns.append(str(writer))
											listOfColumns.append(str(s[1]))
											listOfColumns.append(str(s[0]))
											listOfColumns.append(str(ps))
											pyUtils.writeToCSV(listOfColumns,outDirectory+"/redirect_"+outDirectory+".csv")
						source_list = []					
						for r in r2:
							try:
								source = (r.split()[0] , r)
							except:
								source = (r.split("=")[0], r)
							source_list.append(source)

						for s in source_list:
							for writer in writers:
								pSinks = findFuntionCallContent( writer, fileContent)
								for ps in pSinks:
									if list(find_all(ps,s[0].strip())) != []:
										if re.findall(r"[ \t\n]*\+[ \t\n]*"+ s[0].strip() +"[ \t\n]*\+[ \t\n]*",ps) != [] or  re.findall(r"[ \t\n]*\([ \t\n]*"+ s[0].strip() +"[ \t\n]*\)[ \t\n]*",ps) != []:
											issue_count = issue_count + 1
											print("[i] Open Redirect issue count: " + str(issue_count))
											print("Sink Function: " + writer )
											print("Source call: "+s[1])
											print("Source Variable:  |" + s[0] + "|\nPrinted In \n|" + ps + "|\n")
											listOfColumns = []
											listOfColumns.append(str(issue_count))
											listOfColumns.append(str(filePath))
											listOfColumns.append(str(writer))
											listOfColumns.append(str(s[1]))
											listOfColumns.append(str(s[0]))
											listOfColumns.append(str(ps))
											pyUtils.writeToCSV(listOfColumns,outDirectory+"/redirect_"+outDirectory+".csv")
				except KeyboardInterrupt:
					key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
					if key_choice.lower() == 'c':
						skippedAbruptly["findPossibleRedirect "+filePath] = "KeyboardInterrupt - skipped file"
						pass
					elif key_choice.lower() == 's':
						skippedAbruptly["findPossibleRedirect "+filePath] = "KeyboardInterrupt - skipped analysis"
						return skippedAbruptly
					elif key_choice.lower() == 'q':
						skippedAbruptly["findPossibleRedirect "+filePath] = "KeyboardInterrupt - quit scan"
						raise
					else:
						skippedAbruptly["findPossibleRedirect "+filePath] = "KeyboardInterrupt - skipped file"
						pass
				except Exception as e:
					print(("[X] findPossibleRedirect: Some error occurred: "+ filePath))
					skippedAbruptly["findPossibleRedirect "+filePath] = str(e)
	print("===============================")
	print("[i] Open Redirect Scan finished. Total " + str(issue_count) + " issues found!")
	print("===============================")
	return skippedAbruptly

if __name__ == "__main__":
	directory = input("Enter path to directory: \n> ")
	findPossibleRedirect(directory, ".")