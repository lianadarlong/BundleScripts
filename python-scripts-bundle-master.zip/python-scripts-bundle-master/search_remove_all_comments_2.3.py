import os, re, glob, time, csv, sys, io
import chardet

toSkips = ["NetCracker Technology Corp","All Rights Reserved","/bin/","Convergys","Copyright ","License","!perl"] # comments with these strings to be skipped deletion 
notToSkip = ["external audit purposes only"]
'''
Below is extension repo, which can be updated and accessed
To get start of multi line comment: commentsTypeRepo['.java']['double']['start'] 
To get end of multi line comment: commentsTypeRepo['.ext1']['double']['end']
To get start of single line comment: commentsTypeRepo['.java']['single']
'''
commentsTypeRepo = 	{	
						".java"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".h"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".cc"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".cpp"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".c"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".jsp"	:	{	"single":	"", 
										"double": 	{"start":"<%--","end":"--%>"} 
									},
						".as"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".pas"	:	{	"single":	"//", 
										"double": 	{"start":"(*","end":"*)"} 
									},
						".sql"	:	{	"single":	"--", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".pls"	:	{	"single":	"--", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						'''".htm"	:	{	"single":	"", 
										"double": 	{"start":"<!--","end":"-->"} # there's a chance removing genuine code inside javascript in HTML page because of this 
									},
						".html"	:	{	"single":	"", 
										"double": 	{"start":"<!--","end":"-->"} # there's a chance removing genuine code inside javascript in HTML page because of this 
									},'''
						".scp"	:	{	"single":	"", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".bdy"	:	{	"single":	"--", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".rc"	:	{	"single":	"", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".js"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".css"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".pl"	:	{	"single":	"#", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".py"	:	{	"single":	"#", 
										"double": 	{"start":"'''","end":"'''"} 
									},
						".ts"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".vb"	:	{	"single":	"'", 
										"double": 	{"start":"","end":""} 
									},
						".pm"	:	{	"single":	"#", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".groovy"	:	{	"single":	"//", 
										"double": 	{"start":"/*","end":"*/"} 
									},
						".xml"	:	{	"single":	"", 
										"double": 	{"start":"<!--","end":"-->"} 
									},
						".xsd"	:	{	"single":	"", 
										"double": 	{"start":"<!--","end":"-->"} 
									}
					}

def writeToCSV(listOfColumns, resultFileName):
	if sys.version_info[0] < 3:
		csvfile = open(resultFileName, 'ab')
	else:
		csvfile = open(resultFileName, 'a', newline='', encoding='utf-8')
	writer = csv.writer(csvfile, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
	writer.writerow(listOfColumns)
	csvfile.close()
					
def arrayInString(array, narray, string):
	for a in array:
		if a in string:
			for n in narray:
				if n in string:
					return False
			return True
	return False

def tempClearNonComments(fileContent, start, end):
	tempLines = fileContent.splitlines(True)
	tempFileContent = ""
	for tempLine in tempLines:
		if re.search(r'".*' + re.escape(start) + '.*"',tempLine) or re.search(r"'.*" + re.escape(start) + ".*'",tempLine) or re.search(r'".*' + re.escape(end) + '.*"',tempLine) or re.search(r"'.*" + re.escape(end) + ".*'",tempLine):
			pass
		else:
			tempFileContent = tempFileContent + tempLine
	return tempFileContent

def update_single (filename, outFile, lines, start, multiStart, multiEnd, encodingType, toSkips=[], notToSkip=[]):
	f_out = open(filename, 'wb')
	ext = os.path.splitext(filename)[1].lower()
	for line in lines:
		line = line.decode(encoding=encodingType)
		comment=re.findall(r''+re.escape(start)+'.*',line)
		if comment != []:
			# Check if the comment start is inside quotes (a value in code like test = " something // not a comment";)
			if re.search(r'".*' + re.escape(start) + '.*"',line) or re.search(r"'.*" + re.escape(start) + ".*'",line) or ((ext == '.pl' or ext == '.pm') and (re.search(r"\/.*" + re.escape(start) + ".*\/",line) or "$#" in line)) or (multiStart in comment[0].strip() and multiStart != "") or (multiEnd in comment[0].strip() and multiEnd != ""):
				f_out.write(line.encode())
			elif arrayInString(toSkips, notToSkip, comment[0]):
				f_out.write(line.encode(encoding=encodingType))
			else:
				newLine = line.replace(comment[0].strip(), "")
				writeToCSV([filename, " "+line.strip(), " "+newLine.strip()], outFile)
				f_out.write(newLine.encode())
		else:
			f_out.write(line.encode(encoding=encodingType))
	f_out.close()


def update_multi (filename, outFile, originalFileContent, start, end, singleStart, encodingType, toSkips=[], notToSkip=[]):
	fileContent = originalFileContent.decode(encoding=encodingType)
	tempFileContent = tempClearNonComments(fileContent, start, end)	# Temporarily remove lines where comment start/end is inside quotes (a value in code like test = " something /* not a comment";)
	multiline = re.compile(r'.*(?<=' + re.escape(start) + ')[\s\S]*?(?=' + re.escape(end) + ')',re.MULTILINE|re.IGNORECASE)
	multiline_proper = re.compile(r'(?<=' + re.escape(start) + ')[\s\S]*?(?=' + re.escape(end) + ')',re.MULTILINE|re.IGNORECASE)
	comments = re.findall(multiline,tempFileContent)
	for comment in comments:
		if not arrayInString(toSkips, notToSkip, comment) and not (singleStart in comment.split(start)[0]+start and singleStart != ""):
				comment_proper = re.findall(multiline_proper,comment+end)
				for comment_proper_1 in comment_proper:
					if "-{" not in comment_proper_1 and "}-" not in comment_proper_1:
						fileContent = fileContent.replace(start+comment_proper_1+end, "")
						writeToCSV([filename, start+comment_proper_1+end], outFile)
	file = open(filename, 'wb')
	file.write(fileContent.encode(encoding=encodingType))
	file.close()


def start(myDir):
	timestamp = str(time.time())
	resultFileNameSingle = 'RemovedSingleLineComment_' + timestamp + '.csv'
	resultFileNameMulti = 'RemovedMultiLineComment_' + timestamp + '.csv'
	writeToCSV(["File","Old Line","New Line"],resultFileNameSingle)
	writeToCSV(["File","Removed Comment"],resultFileNameMulti)
	skippedAbruptly = {}
	for root, subdirs, files in os.walk(myDir):
		for file in os.listdir(root):
			filename = os.path.join(root, file)
			if os.path.isdir(filename) or ".svn" in filename:
				pass
			else:
				try:
					ext = os.path.splitext(filename)[1].lower()
					if ext in list(commentsTypeRepo.keys()):
						print(("[i] Working with: "+ filename))
						myfile = open (filename, "rb")
						fileContent = myfile.read()
						encodingType = chardet.detect(fileContent)['encoding']
						if encodingType == None:
							encodingType = "utf-8"
						myfile.close()
						if commentsTypeRepo[ext]['double']['start'] != "" and commentsTypeRepo[ext]['double']['end'] != "":
							update_multi(filename, resultFileNameMulti, fileContent, commentsTypeRepo[ext]['double']['start'], commentsTypeRepo[ext]['double']['end'], commentsTypeRepo[ext]['single'], encodingType, toSkips, notToSkip)
						else:
							print(("[W] Skipped File for Multi Line Comment: "+ filename))
						myfile = open(filename, "rb")
						lines = myfile.readlines()
						myfile.close()
						if commentsTypeRepo[ext]['single'] != "":
							update_single(filename, resultFileNameSingle, lines, commentsTypeRepo[ext]['single'], commentsTypeRepo[ext]['double']['start'], commentsTypeRepo[ext]['double']['end'], encodingType, toSkips, notToSkip)	#Removing single line first to avoid considering multi line comment start inside single line comments 
						else:
							print(("[W] Skipped File for Single Line Comment: "+ filename))
				except:
					print(("[X] Some error occurred: "+ filename))
					skippedAbruptly[filename] = str(sys.exc_info())
	if skippedAbruptly != {}:
		print("Below files were skipped abruptly!\n")
		for s in skippedAbruptly.keys():
			print( s + ":  " + skippedAbruptly[s])
			try:
				errorFile = open('error.txt','a')
				errorFile.write( s + ":  " + skippedAbruptly[s] + "\n")
				errorFile.close()
			except:
				pass

if __name__ == "__main__":
	myDir = ""
	try:
		myDir = sys.argv[1]
		start(myDir)
	except:
		print("Usage: python search_remove_all_comments_XX.X.py \"/path/to/directory\"")

