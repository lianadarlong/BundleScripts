import os
import pyUtils

skippedAbruptly = {}

def findPathAndExtention(directory, outDirectory):
	global skippedAbruptly
	print("[i] Analysing paths and extensions at "+directory+" ...")
	pyUtils.writeToCSV(["Extension","Count"],outDirectory+"/pathsAndExtensions_extList"+outDirectory+".csv")
	pyUtils.writeToCSV(["Path","Extension"],outDirectory+"/pathsAndExtensions_pathList"+outDirectory+".csv")
	extensions = {}
	for root, subdirs, files in os.walk(directory):
		for file in os.listdir(root):
			try:
				filePath = os.path.join(root, file)
				if os.path.isdir(filePath):
					pass
				else:
					filename, file_extension = os.path.splitext(filePath)
					path = filePath.replace(directory,"")
					if file_extension in extensions.keys():
						extensions[file_extension] = extensions[file_extension] + 1
					else:
						extensions[file_extension] = 1
					pyUtils.writeToCSV([path, file_extension],outDirectory+"/pathsAndExtensions_pathList"+outDirectory+".csv")
			except KeyboardInterrupt:
				key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
				if key_choice.lower() == 'c':
					skippedAbruptly["findPathAndExtention "+filePath] = "KeyboardInterrupt - skipped file"
					pass
				elif key_choice.lower() == 's':
					skippedAbruptly["findPathAndExtention "+filePath] = "KeyboardInterrupt - skipped analysis"
					return skippedAbruptly
				elif key_choice.lower() == 'q':
					skippedAbruptly["findPathAndExtention "+filePath] = "KeyboardInterrupt - quit scan"
					raise
				else:
					skippedAbruptly["findPathAndExtention "+filePath] = "KeyboardInterrupt - skipped file"
					pass
			except Exception as e:
				print(("[X] findPathAndExtention: Some error occurred: "+ filePath))
				skippedAbruptly["findPathAndExtention "+filePath] = str(e)
	for ext in extensions:
		pyUtils.writeToCSV([ext,extensions[ext]],outDirectory+"/pathsAndExtensions_extList"+outDirectory+".csv")
	print("===============================")
	print("[i] Completed analyzing paths and extensions. Below is list of extensions.")
	sortedExt = sorted(extensions, key=extensions.get, reverse=True)
	for ext in sortedExt:
		print("[i]\t"+str(ext)+"\t"+str(extensions[ext]))
	print("===============================")
	return skippedAbruptly

if __name__ == "__main__":
	directory = input("Enter path to directory: \n> ")
	findPathAndExtention(directory, ".")