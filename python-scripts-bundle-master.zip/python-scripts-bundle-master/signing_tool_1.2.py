import os, re,glob, sys

comment=sys.argv[2]

d={".java": ["// ",""],
   ".h":    ["/* "," */"],
   ".cc":   ["// ",""],
   ".as":   ["/* "," */"],
   ".pas":  ["(* "," *)"],
   ".sql":  ["-- ",""],
   ".jsp":  ["<%-- "," --%>"],
   ".c":    ["/* "," */"],
   ".scp":  ["/* "," */"],
   ".bdy":  ["/* "," */"],
   ".rc":   ["/* "," */"],
   ".js":   ["// ",""],
   ".css":  ["/* "," */"],
   ".be":   ["<!-- "," -->"],
   ".hh":   ["// ",""],
   ".form": ["<!-- "," -->"],
   ".pl":   ["# ",""],
   ".uientity":	["<!-- "," -->"],
   ".od":	["<!-- "," -->"],
   ".function":	["<!-- "," -->"],
   ".uipage":	["<!-- "," -->"],
   ".py":	["# ",""],
   ".tpl":	["{* "," *}"],
   ".ce":	["<!-- "," -->"],
   ".vm":	["## ",""],
   ".rdb":	["<!-- "," -->"],
   ".sqt":	["-- ",""],
   ".or":	["<!-- "," -->"],
   ".webflow":	["<!-- "," -->"],
   ".sq":	["<!-- "," -->"],
   ".rpt":	["# ",""],
   ".ctl":	["-- ",""],
   ".pc":	["/* "," */"],
   ".ox":	["<!-- "," -->"],
   ".webmenu":	["<!-- "," -->"],
   ".task":	["<!-- "," -->"],
   ".ba":	["<!-- "," -->"],
   ".ts":	["/* "," */"],
   ".bo":	["<!-- "," -->"],
   ".vb":	["' ",""],
   ".descriptor":	["<!-- "," -->"],
   ".svc":	["<!-- "," -->"],
   ".webtree":	["<!-- "," -->"],
   ".dpr":	["(* "," *)"],
   ".bas":	["' ",""],
   ".pm":	["# ",""],
   ".pcc":	["/* "," */"],
   ".groovy":	["// ",""],
   ".soy":	["/* "," */"],
   ".g":	["// ",""],
   ".pls":	["-- ",""],
   ".tcl":	["# ",""],
   ".cpp":	["// ",""],
   ".cbl":	["* ",""],
   ".asn":	["-- "," --"],
   ".model":["// ",""],
   ".go":["// ",""]}
   
myDir=sys.argv[1]

file_amount=0

def line_prepender(filename, type):
	try:
		print("[i] Signing " + filename)
		f = open(filename, 'rb')
		content = f.read()
		f.close()
		line=d[type][0]+comment+d[type][1]
		f = open(filename, 'wb')
		if(b'\r\n' in content):
			line = line + '\r\n'
		else:
			line = line + '\n'
		f.write(bytes(line, encoding="ascii") + content)
		f.close()
		sf = open("signedFiles.txt","a")
		sf.write(filename+"\n")
		sf.close()
	except Exception as e:
		print("[X] Error processing " + filename + str(e))
		ef = open("error.txt","a")
		ef.write(filename+"\n")
		ef.close()
			
    
def find_files(key):
	for root, subdirs, files in os.walk(myDir):
		for file in os.listdir(root):
			filename = os.path.join(root, file)
			if os.path.isdir(filename):
				pass
			elif ".svn" in filename:
				pass
			elif filename[-len(key):].lower() == key:
				try:		
					line_prepender(filename,key)			
					global file_amount
					file_amount+=1
				except:
					continue


for key in d:
	print ("Working with file types: "+key)
	find_files(key)

f_res=open('results', 'w')
f_res.write("Files updated: "+str(file_amount))
f_res.close()	

