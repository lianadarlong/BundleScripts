import os
import sys
import re 
import time
import csv
import hashlib
import pyUtils

skippedAbruptly = {}

def removeComments(pageContent):
	cleanContent = ""
	cleanContent = re.sub(re.compile("//.*?\n" ) ,"", pageContent)
	cleanContent = re.sub(re.compile("/\*.*?\*/",re.DOTALL ) ,"", cleanContent)
	return cleanContent

def findFuntionCallContent( functionName, pageContent ):
	contentList = []
	bCount = -1
	cCount = 0
	occurrences =  list(find_all(pageContent, functionName))
	for i in occurrences:
		content = ""
		bCount = -1
		cCount = 0
		tempStr = pageContent[i+len(functionName):len(pageContent)].strip()
		if tempStr[0] == "(":
			for character in tempStr:
				if character == "(":
					bCount = bCount + 1
				if character == ")" and bCount == 0:
					content = tempStr[:cCount+1]
					break
				if character == ")" and bCount != 0:
					bCount = bCount - 1
				cCount = cCount + 1
		if content != "":
			contentList.append((functionName,content.strip()[1:-1]))
	return contentList

def findLikelyVariableContent( variableName, pageContent ):
	contentList = []
	variableAppends = []
	variableAppendsRaw = re.findall(r"[\w\s.]*" + re.escape(variableName) + r"[\w\s.]*\.append[\s]*\(",pageContent,re.IGNORECASE)
	for v in variableAppendsRaw:
		variableAppends.append(v.strip())
	variableAppends = list(dict.fromkeys(variableAppends))
	for v1 in variableAppends:
		contentList = contentList + findFuntionCallContent(v1[:-1], pageContent)
	
	variableLines = re.findall(r"[\w\s().]*" + re.escape(variableName) + r"[\w\s().]*=",pageContent.lower())
	for v in variableLines:
		occurrences =  list(find_all(pageContent.lower(), v))
		for i in occurrences:
			content = ""
			quoteFlag = 0
			tempStr = pageContent[i+len(v):len(pageContent)]
			if tempStr.strip().startswith('"+query);') or tempStr.strip().startswith('" + query);') or tempStr.strip().startswith('" +query);') or tempStr.strip().startswith('"+ query);'): # hardcoded false positive 
				pass
			if tempStr.strip().startswith('"+ID);') or tempStr.strip().startswith('" + ID);') or tempStr.strip().startswith('" +ID);') or tempStr.strip().startswith('"+ ID);'): # hardcoded false positive 
				pass
			else:
				previousCharacter = ""
				for character in tempStr:
					if character == '"':
						if previousCharacter == '\\':
							pass
						elif quoteFlag == 0:
							quoteFlag = 1
						else:
							quoteFlag = 0
					if character == ';' and quoteFlag == 0:
						break
					content = content + str(character)
					previousCharacter = character
				if content != "":
					contentList.append((pageContent[i:i+len(v)],content))
	return contentList

def find_all(a_str, sub):
    start = 0
    while True:
        start = a_str.find(sub, start)
        if start == -1: return
        yield start
        start += len(sub) # use start += 1 to find overlapping matches
	
def findQueries(fileContent):
	queries = []
	query_variables = ["query","qry","sql"]
	sql_function = ["executeQuery","executeSelect","selectForList","findBySQL","executeUpdate","executeDelete","selectForObject","executeQuerySingleI","procedureCall","prepareStatement","createStatement","executeStatement","selectForObjectOrNull","prepareCall","moveOrderedObjects","executeBatch","executeQuerySingle","executeQueryMultiple","QueryExecutor","generateInputLine","getObjectsByQuery","executeProcedure","queryForObject","getEntitiesByQuery"]
	for sf in sql_function:
		queries = queries + findFuntionCallContent(sf, fileContent)
	for qv in query_variables:
		queries = queries + findLikelyVariableContent(qv, fileContent)
	return queries

def findPossibleSQLi(scanDirectory, outDirectory):
	global skippedAbruptly
	issue_count = 0
	userInputFunctions = ["getParameter","getValidParameter","getValidUrlParameter","getRequestParameter","getParameterByName","getParameterValues"]  # Update any new functions/calls here, which gets user inputs
	pyUtils.writeToCSV(["Count","File","Source call","Sink Query For","Sink Query","hash"],outDirectory+"/sqli_"+outDirectory+".csv")
	for root, subdirs, files in os.walk(scanDirectory):
		for file in os.listdir(root):
			filePath = os.path.join(root, file)
			if os.path.isdir(filePath):
				pass
			else:
				try:
					if filePath[-3:] == "jsp" or filePath[-3:] == "inc" or filePath[-4:] == "java":    # Update any new file extensions here 
						content_file = open(filePath, 'r', encoding ="utf8", errors="replace")
						fileContent = content_file.read()
						fileContent = removeComments(fileContent)
						print("[i] Finding possible SQLi in " + filePath)
						queries = []
						queries = findQueries(fileContent)
						if queries != []:
							for userInputFunction in userInputFunctions:
								userInputLines = re.findall(r"\w+[ \s]*=[ \s\w().]*" + re.escape(userInputFunction) + r"[ \s]*\(.*\)",fileContent)
								source_list = []
								for r in userInputLines:
									try:
										source = (r.split()[0] , r)
									except:
										source = (r.split("=")[0], r)
									source_list.append(source)
								for s in source_list:
									for q in queries:
										plusBothSides = re.findall( r"[\s]*\+[\s]*" + re.escape(s[0].strip()) + r"[\s]*\+[\s]*" , q[1] )
										plusAtStart = re.findall(r"[\s=]+" + re.escape(s[0].strip()) + r"[\s]*\+[\s]*",q[1]) 
										plusAtEnd = re.findall(r"[\s]*\+[\s]*" + re.escape(s[0].strip()) + r"[\s;]+",q[1])
										Same = s[0].strip() == q[1].strip()
										if plusBothSides != [] or plusAtStart != [] or plusAtEnd != [] or Same:
											issue_count = issue_count + 1
											print("\n#####################################"+str(issue_count)+"#######################################\nFile Path: " +  filePath + "\nSource Call: " + s[1].strip() +"\nSink Query For: " + q[0].strip() + "\nSink Query:" + q[1].strip() + "\n===============================" )
											listOfColumns = []
											listOfColumns.append(str(issue_count))
											listOfColumns.append(str(filePath))
											listOfColumns.append(str(s[1].strip()))
											listOfColumns.append(str(q[0].strip()))
											listOfColumns.append(q[1].strip())
											tempHashString = str(filePath).replace(scanDirectory,'') + str(s[1].strip()) + str(q[0].strip()) + q[1].strip()
											hash = hashlib.md5(tempHashString.encode())
											listOfColumns.append(str(hash.hexdigest()))
											pyUtils.writeToCSV(listOfColumns,outDirectory+"/sqli_"+outDirectory+".csv")
				except KeyboardInterrupt:
					key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
					if key_choice.lower() == 'c':
						skippedAbruptly["findPossibleSQLi "+filePath] = "KeyboardInterrupt - skipped file"
						pass
					elif key_choice.lower() == 's':
						skippedAbruptly["findPossibleSQLi "+filePath] = "KeyboardInterrupt - skipped analysis"
						return skippedAbruptly
					elif key_choice.lower() == 'q':
						skippedAbruptly["findPossibleSQLi "+filePath] = "KeyboardInterrupt - quit scan"
						raise
					else:
						skippedAbruptly["findPossibleSQLi "+filePath] = "KeyboardInterrupt - skipped file"
						pass
				except Exception as e:
					print(("[X] findPossibleSQLi: Some error occurred: "+ filePath))
					skippedAbruptly["findPossibleSQLi "+filePath] = str(e)
	print("===============================")
	print("[i] SQLi Scan finished. Total " + str(issue_count) + " issues found!")
	print("===============================")
	return skippedAbruptly

if __name__ == "__main__":
	directory = input("Enter path to directory: \n> ")
	findPossibleSQLi(directory, ".")