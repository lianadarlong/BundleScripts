import pyUtils
import re
import sys
import os

skippedAbruptly = {}
searchInExtensions = ['.java', '.h', '.cc', '.cpp', '.c', '.jsp', '.as', '.pas', '.sql', '.pls', '.htm', '.html', '.scp', '.bdy', '.rc', '.js', '.css', '.pl', '.py', '.ts', '.vb', '.pm', '.groovy', '.xml', '.xsd','.txt','.yaml','.conf','.config','.properties','.sh','.yml','.json','.cfg'] 
passwordVariables = ["passw","secret","pwd","credential","credentials","password","pass"] #Update variables name as possible 
regexList = []
for passwordVariable in passwordVariables:
	regexList.append(re.compile(passwordVariable+"['\"\s\)\(]*[=:>]+.*",  re.MULTILINE|re.IGNORECASE))
riskyReg = '|'.join(x.pattern for x in regexList)

regex_dictionary = {
					"generic_1":	riskyReg,
					"generic_2":	re.compile(r'return[ \t]+[\'\"].*password.*[\'\"]',re.IGNORECASE),
					"generic_3":	re.compile(r'return[ \t]+[\'\"].*secret.*[\'\"]',re.IGNORECASE),
					"generic_4":	re.compile(r'return[ \t]+[\'\"].*credential.*[\'\"]',re.IGNORECASE),
					"generic_5":	re.compile(r'password.add\(.*',re.IGNORECASE),
					"generic_6":	re.compile(r'secret.add\(.*',re.IGNORECASE),
					"generic_7":	re.compile(r'credential.add\(.*',re.IGNORECASE),
					"generic_8":	re.compile(r'credentials.add\(.*',re.IGNORECASE),
					"generic_9":	re.compile(r'SALT\(value=".*',re.IGNORECASE),
					"generic_10":	re.compile(r'\WSHA-1\W',re.IGNORECASE),
					"generic_11":	re.compile(r'\WSHA1\W',re.IGNORECASE),
					"generic_12":	re.compile(r'\WMD5\W',re.IGNORECASE),
					"generic_13":	re.compile(r'\WTOP SECRET\W',re.IGNORECASE),
					"generic_14":	re.compile(r'\WCLASSIFIED\W',re.IGNORECASE),
					"generic_15":	re.compile(r'\WBEGIN CERTIFICATE\W',re.IGNORECASE),
					"generic_16":	re.compile(r'\Wjdbc:\W',re.IGNORECASE),
					"generic_17":	re.compile(r'\Wcrknet\W',re.IGNORECASE),
					"generic_18":	re.compile(r'\Wsysadm\W',re.IGNORECASE),
					"generic_19":	re.compile(r'\W[\'\"]geneva_admin[\'\"]\W',re.IGNORECASE)
					}

def findHardcodedPassword(filename, outFile):
	global skippedAbruptly
	global regex_hardcodedPassword
	if os.stat(filename).st_size < 5475000:
		print("[i] Finding hard-coded/vulnerable sensitive info in " + filename)
		with open(filename, "r", encoding ="utf8", errors="replace") as theFile:
			filecontent = theFile.read()
			for regex in regex_dictionary.keys():
				issues = re.findall(regex_dictionary[regex],filecontent)
				if issues != []:
					for issue in issues:
						print("[X] found possible hard-coded credentials in " + filename)
						listOfColumns = []
						listOfColumns.append(filename)
						listOfColumns.append(issue)
						listOfColumns.append(str(regex_dictionary[regex]))
						pyUtils.writeToCSV(listOfColumns,outFile)
			theFile.close()


def findHardcodedPasswords(directory, outDirectory, extensions=""):
	global skippedAbruptly
	global searchInExtensions
	if extensions != "":
		for ext in extensions.split(","):
			if ext not in searchInExtensions:
				searchInExtensions.append(ext)
	pyUtils.writeToCSV(["Filename","hard-coded/vulnerable sensitive info","Regex"],outDirectory+"/passwords_"+outDirectory+".csv")
	for root, subdirs, files in os.walk(directory):
		for file in os.listdir(root):
			filename = os.path.join(root, file)
			if os.path.isdir(filename):
				pass
			elif(pyUtils.is_hidden(filename)):
				pass
			else:
				name, file_extension = os.path.splitext(filename)
				if file_extension in searchInExtensions:
					try:
						findHardcodedPassword(filename, outDirectory+"/passwords_"+outDirectory+".csv")
					except KeyboardInterrupt:
						key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
						if key_choice.lower() == 'c':
							skippedAbruptly["findHardcodedPassword "+filename] = "KeyboardInterrupt - skipped file"
							pass
						elif key_choice.lower() == 's':
							skippedAbruptly["findHardcodedPassword "+filename] = "KeyboardInterrupt - skipped analysis"
							return skippedAbruptly
						elif key_choice.lower() == 'q':
							skippedAbruptly["findHardcodedPassword "+filename] = "KeyboardInterrupt - quit scan"
							raise
						else:
							skippedAbruptly["findHardcodedPassword "+filename] = "KeyboardInterrupt - skipped file"
							pass
					except Exception as e:
						print(("[X] findHardcodedPassword: Some error occurred: "+ filename + str(e)))
						skippedAbruptly["findHardcodedPassword "+filename] = str(e)
	return skippedAbruptly


if __name__ == "__main__":
	directory = input("Enter path to directory: \n> ")
	findHardcodedPasswords(directory, ".")