
import pySensitiveInfos
import pyRiskyWords
import pyWebrootTracker
import pyFindPossibleXSS
import pyFindPossibleSQLi
import pyFindPossibleRedirect
import pyFindPathAndExtensions
import pyFindPossibleBackdoor
import time
from datetime import datetime
import sys
import os

skippedAbruptly = {}
globalInput = {}
version = "v1.0"

class Switcher(object):
	global globalInput
	def __init__(self):
		pass
	def scanFor(self, option):
		methodName = 'option_' + option
		method = getattr(self, methodName, lambda : print("Invalid Choice!"))
		return method()
	def option_1(self):
		errors = pyWebrootTracker.webrootTracker("CREATE", globalInput["directory"], globalInput["outDirectory"])
		return errors
	def option_2(self):
		errors = pyWebrootTracker.webrootTracker("COMPARE", globalInput["directory"], globalInput["outDirectory"], globalInput["2"])
		return errors
	def option_3(self):
		errors = pySensitiveInfos.findHardcodedPasswords(globalInput["directory"], globalInput["outDirectory"], globalInput["3"])
		return errors
	def option_4(self):
		errors = pyRiskyWords.findRiskyWords(globalInput["directory"], globalInput["outDirectory"], globalInput["4"])
		return errors
	def option_5(self):
		errors = pyFindPossibleXSS.findPossibleXSS(globalInput["directory"], globalInput["outDirectory"])
		return errors
	def option_6(self):
		errors = pyFindPossibleSQLi.findPossibleSQLi(globalInput["directory"], globalInput["outDirectory"])
		return errors
	def option_7(self):
		errors = pyFindPossibleRedirect.findPossibleRedirect(globalInput["directory"], globalInput["outDirectory"])
		return errors
	def option_8(self):
		errors = pyFindPathAndExtensions.findPathAndExtention(globalInput["directory"], globalInput["outDirectory"])
		return errors
	def option_9(self):
		errors = pyFindPossibleBackdoor.findPossibleBackdoors(globalInput["directory"], globalInput["outDirectory"])
		return errors


def getChoices(options):
	while True:
		choices = input("\nEnter your choices without spaces. Example: 1234AB\n> ")
		choices = choices.upper()
		if "Z" in choices:
			skippedAbruptly["User Exit"] = "Option Z"
			return ""
		choices = list(choices)
		choices = list(dict.fromkeys(choices))
		for choice in choices:
			if choice not in options.keys():
				print("Wrong choices! Try again.")
				choices = getChoices(options)
				break
		return choices

def getInputs(choices):
	global globalInput
	if choices != "":
		globalInput["directory"] = input("\nEnter directory to scan: (Recommended to enter full path)\n> ")
		choiceSpecificInputs = {
							"1" : "",
							"2" : "\nEnter path to old DB for webroot comparison:\n> ",
							"3" : "\nSearching in these extensions for Hard-coded Passwords: " + str(pySensitiveInfos.searchInExtensions) + "\nEnter additional comma separated extensions in .ext format if needed (.ext1,.ext2,.ext3)\n>",
							"4" : "\nSearching in these extensions for Risky Words: " + str(pySensitiveInfos.searchInExtensions) + "\nEnter additional comma separated extensions in .ext format if needed (.ext1,.ext2,.ext3)\n>",
							"5" : "",
							"6" : "",
							"7" : "",
							"7" : ""
							}
		for key in choiceSpecificInputs:
			if key in choices:
				if choiceSpecificInputs[key] != "":
					globalInput[key] = input(choiceSpecificInputs[key])
	timestamp = datetime.timestamp(datetime.now())
	globalInput["outDirectory"] = "out_" + str(timestamp)
	os.mkdir(globalInput["outDirectory"])
	print("###################################################\n[i] Press Control+c to interrupt with options\n")
	print("###################################################\n[i]Scan started at: " + str(datetime.fromtimestamp(timestamp)))

def start(choices):
	global skippedAbruptly
	getInputs(choices)
	switch = Switcher()
	for choice in choices:
		errors = switch.scanFor(choice)
		skippedAbruptly.update(errors)


if __name__ == "__main__":
	options = {
				"1"	:	"Create DB for a webroot",
				"2"	:	"Compare webroot with older webroot stored in DB",
				"3"	:	"Find hard-coded/vulnerable sensitive info",
				"4"	:	"Find risky abusive words",
				"5" :	"Find possible XSS",
				"6" :	"Find possible SQL Injection",
				"7" :	"Find possible Open Redirect",
				"8" :	"Analyze paths and extensions",
				"9"	:	"Find possible code/command execution and backdoors",
				"Z"	:	"Exit"
			}
	cover = '''	
###########################################################################
 This python script bundle is property of Netcracker Technology and to be 
 used for internal purpose only.
 Developed with: Python 3
 Bundled with: pyInstaller
 Version: '''+version+'''
###########################################################################
'''	#thanks to http://patorjk.com/software/taag/#p=display&f=Big&t=pyScanNC 
	try:
		print(cover)
		for option in options.keys():
			print("  " + option + "  " + options[option])
		choices = getChoices(options)
		start(choices)
		if skippedAbruptly != {}:
			print("###################################################\nErrors:\n")
			for key in skippedAbruptly:
				print("[X] " + key + "\t\t\t" + skippedAbruptly[key])
				try:
					errorFile = open(globalInput["outDirectory"] + '/error.txt','a')
					errorFile.write("[X] " + key + "\t\t\t" + skippedAbruptly[key]+"\n")
					errorFile.close()
				except:
					print("[X] Error while writing errors!!!")
		
	except:
		print("Unknown Error!")
		skippedAbruptly["Main Error:"] = str(sys.exc_info())
		if skippedAbruptly != {}:
			print("###################################################\nErrors:\n")
			for key in skippedAbruptly:
				print("[X] " + key + "\t\t\t" + skippedAbruptly[key])
				try:
					errorFile = open(globalInput["outDirectory"] + '/error.txt','a')
					errorFile.write("[X] " + key + "\t\t\t" + skippedAbruptly[key]+"\n")
					errorFile.close()
				except:
					pass
	print("###################################################\n[i]Scan completed at: " + str(datetime.now()))
	print("\n[i]Outputs are at: " + globalInput["outDirectory"])
