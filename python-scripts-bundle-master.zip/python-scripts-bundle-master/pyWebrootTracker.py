import pyUtils
import os
import sqlite3
import time
import sys
import difflib
import base64

skippedAbruptly = {}

def split_len(seq, length):
	return [seq[i:i+length] for i in range(0, len(seq), length)]

def findDiff(oldContent, newContent, resultDir, filename):
	newOrEditedLines = []
	removedLines = []
	diff = difflib.unified_diff(oldContent.splitlines(), newContent.splitlines())
	for line in list(diff):
		if line[0] == '+':
			newOrEditedLines.append(line)
		elif line[0] == '-':
			removedLines.append(line)
	if newOrEditedLines != [] or removedLines != []:
		diffHTMLHandler = difflib.HtmlDiff()
		HTML = diffHTMLHandler.make_file(oldContent.splitlines(), newContent.splitlines(), "Old", "New", context=True)
		outFile = open(resultDir + "/html_compare_results/" + os.path.basename(filename) + ".html",'w')
		outFile.write(HTML)
		outFile.close()
	return (newOrEditedLines, removedLines)

def createDB(directory, resultDir):	# creates jspDB__.db with filepath, checksum, base64Content 
	global skippedAbruptly
	dbName = resultDir + "/jspDB_" + str(os.path.basename(directory)) + "_.db"
	conn = sqlite3.connect(dbName)
	c = conn.cursor()
	c.execute("CREATE TABLE JSPFiles (filepath, filehash, b64Content)")
	for root, subdirs, files in os.walk(directory):
		for file in os.listdir(root):
			try:
				filePath = os.path.join(root, file)
				if os.path.isdir(filePath):
					pass
				else:
					if filePath[-3:].lower() == "jsp" or filePath[-3:].lower() == "inc" or filePath[-3:].lower() == "htm" or filePath[-4:].lower() == "html" or filePath[-2:].lower() == "nc":    #add more file types if needed 
						filehash = pyUtils.checksum_md5(filePath, directory)
						with open(filePath,'r') as f:
							fileContent = f.read()
							fileContentBytes = fileContent.encode('ascii')
							b64Content = base64.b64encode(fileContentBytes)
							param = (filePath[len(directory):].replace("\\","/"),filehash,b64Content)
							print("[i] File found: " + filePath[len(directory):].replace("\\","/"))
							c.execute("INSERT INTO JSPFiles VALUES (?,?,?)",param)
			except KeyboardInterrupt:
				key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
				if key_choice.lower() == 'c':
					skippedAbruptly["DBCreate "+filePath] = "KeyboardInterrupt - skipped file"
					pass
				elif key_choice.lower() == 's':
					skippedAbruptly["DBCreate "+filePath] = "KeyboardInterrupt - skipped analysis"
					return dbName
				elif key_choice.lower() == 'q':
					skippedAbruptly["DBCreate "+filePath] = "KeyboardInterrupt - quit scan"
					raise
				else:
					skippedAbruptly["DBCreate "+filePath] = "KeyboardInterrupt - skipped file"
					pass
			except Exception as e:
				print("[X] DBCreate: Some error occurred: "+ filePath)
				skippedAbruptly["DBCreate "+filePath] = str(e)
	conn.commit()
	conn.close()
	return dbName

def compareDB(oldDB, newDB, directory, resultDir):	#output compareResults__.csv file with new files, modified files, 
	resultCSV_NEW = resultDir + "/webroot_new_files_" + str(os.path.basename(directory)) + "_"+resultDir+".csv"
	resultCSV_MODIFIED = resultDir + "/webroot_modified_files_" + str(os.path.basename(directory)) + "_"+resultDir+".csv"
	pyUtils.writeToCSV(["Filepaths"],resultCSV_NEW)
	pyUtils.writeToCSV(["Filepaths","New/Edited Lines","Old/Removed Lines"],resultCSV_MODIFIED)
	connOld = sqlite3.connect(oldDB)
	connNew = sqlite3.connect(newDB)
	connOldc = connOld.cursor()
	connNewc = connNew.cursor()
	connOldc.execute("SELECT filepath FROM JSPFiles")
	connNewc.execute("SELECT filepath FROM JSPFiles")
	newFiles = set(connNewc.fetchall()) - set(connOldc.fetchall())
	print("[i] Searching for new files")
	for newFile in newFiles:
		print("[!] New file found: " + newFile[0])
		pyUtils.writeToCSV([newFile[0]], resultCSV_NEW)
	connOldc.execute("SELECT filepath, b64Content FROM JSPFiles")
	print("[i] Searching for modified files")
	for jspFile in connOldc.fetchall():
		try:
			newOrEditedLines = []
			removedLines = []
			connNewc.execute("SELECT b64Content FROM JSPFiles WHERE filepath = ?",[jspFile[0]])
			b64content = connNewc.fetchall()
			if b64content != []:
				newOrEditedLines, removedLines = findDiff(base64.b64decode(jspFile[1]).decode('ascii'), base64.b64decode(b64content[0][0]).decode('ascii'), resultDir, jspFile[0])
				newOrEditedLinesToWrite = ""
				removedLinesToWrite = ""
				for newOrEditedLine in newOrEditedLines:
					newOrEditedLinesToWrite = newOrEditedLinesToWrite + "\n" + newOrEditedLine
				for removedLine in removedLines:
					removedLinesToWrite = removedLinesToWrite + "\n" + removedLine
				if newOrEditedLinesToWrite != "" or removedLinesToWrite != "":	#Check if no new line or removed line identified 
					if len(newOrEditedLinesToWrite) <= 32000 and len(removedLinesToWrite) <= 32000:	#excel only allows ~32000 characters per cell, if written more - excel breaks. 
						pyUtils.writeToCSV([jspFile[0],newOrEditedLinesToWrite,removedLinesToWrite],resultCSV_MODIFIED)
					elif len(newOrEditedLinesToWrite) > 32000 and len(removedLinesToWrite) < 32000:
						for TempNewOrEditedLinesToWrite in split_len(newOrEditedLinesToWrite, 32000):
							pyUtils.writeToCSV([jspFile[0],TempNewOrEditedLinesToWrite,removedLinesToWrite],resultCSV_MODIFIED)
					elif len(newOrEditedLinesToWrite) < 32000 and len(removedLinesToWrite) > 32000:
						for TempRemovedLinesToWrite in split_len(removedLinesToWrite, 32000):
							pyUtils.writeToCSV([jspFile[0],newOrEditedLinesToWrite,TempRemovedLinesToWrite],resultCSV_MODIFIED)
					else:
						for TempNewOrEditedLinesToWrite, TempRemovedLinesToWrite in zip(split_len(newOrEditedLinesToWrite, 32000),split_len(removedLinesToWrite, 32000)):
							pyUtils.writeToCSV([jspFile[0],TempNewOrEditedLinesToWrite,TempRemovedLinesToWrite],resultCSV_MODIFIED)			
		except KeyboardInterrupt:
			key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
			if key_choice.lower() == 'c':
				skippedAbruptly["DBCompare "+jspFile[0]] = "KeyboardInterrupt - skipped file"
				pass
			elif key_choice.lower() == 's':
				skippedAbruptly["DBCompare "+jspFile[0]] = "KeyboardInterrupt - skipped analysis"
				return (resultCSV_NEW, resultCSV_MODIFIED)
			elif key_choice.lower() == 'q':
				skippedAbruptly["DBCompare "+jspFile[0]] = "KeyboardInterrupt - quit scan"
				raise
			else:
				skippedAbruptly["DBCompare "+jspFile[0]] = "KeyboardInterrupt - skipped file"
				pass
		except Exception as e:
			print("[X] DBCompare: Some error occurred: "+ jspFile[0])
			skippedAbruptly["DBCompare "+jspFile[0]] = str(e)							
	return (resultCSV_NEW, resultCSV_MODIFIED)
	
def webrootTracker(mode, directory, resultDir, oldDBname="NA"):
	global skippedAbruptly
	if mode.lower() == "create":
		newDBName = createDB(directory, resultDir)
		print("[i] New DB Created: " + newDBName)
	elif mode.lower() == "compare":
		newDBName = createDB(directory, resultDir)
		print("[i] New DB Created: " + newDBName)
		os.mkdir(resultDir + "/html_compare_results")
		resultCSV_NEW,  resultCSV_MODIFIED = compareDB(oldDBname, newDBName, directory, resultDir)
		try:
			if os.stat(resultCSV_NEW).st_size != 0:
				print("[i] New file paths are stored in: " + resultCSV_NEW)
			else:
				print("[i] No new files found.")
		except:
			pass
		try:
			if os.stat(resultCSV_MODIFIED).st_size != 0:
				print("[i] Modified files details are stored in: " + resultCSV_MODIFIED)
			else:
				print("[i] No modified files found.")
		except:
			pass
	return skippedAbruptly


if __name__ == '__main__':
	usageText = "\nUsage:\npython pyWebrootTracker.py CREATE /path/to/web-root/ \npython pyWebrootTracker.py COMPARE /path/to/web-root/ jspDB_FILE.db\n"
	now = time.time()
	timestamp = str(now)
	oldDBname = ""
	resultDir = "outputFolder_" + timestamp
	os.mkdir(resultDir)
	try:
		mode = sys.argv[1]
		directory = sys.argv[2]
		if directory[-1] == "\\" or directory[-1] == "/":
			directory = directory[:-1]
		if mode.lower() == "compare":
			oldDBname = sys.argv[3]
	except:
		print(usageText)
		exit()
	webrootTracker(mode, directory, resultDir, oldDBname)

