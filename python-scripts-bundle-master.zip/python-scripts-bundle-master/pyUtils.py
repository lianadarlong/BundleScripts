import csv 
import sys
import os
import hashlib

def writeToCSV(listOfColumns, resultFileName):
	if sys.version_info[0] < 3:
		csvfile = open(resultFileName, 'ab')
	else:
		csvfile = open(resultFileName, 'a', newline='', encoding='utf-8')
	writer = csv.writer(csvfile, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
	writer.writerow(listOfColumns)
	csvfile.close()

def is_hidden(filepath):
	name = os.path.basename(os.path.abspath(filepath))
	return name.startswith('.') or name.endswith('.svn-base') or ".svn" in filepath

def checksum_md5(filepath, directory):	#calculates checksum of a file with respect to file content and filepath from web-root 
	md5 = hashlib.md5()
	try:
		with open(filepath,'rb') as f: 
			for chunk in iter(lambda: f.read(8192), b''): 
				md5.update(chunk)
		md5.update(filepath[len(directory):].replace("\\","/"))    # add file path to hash, path forced to have / instead of \ to generalize hash in all environment 
		return md5.hexdigest()
	except:
		return "HASH_NOT_CALCULATED"