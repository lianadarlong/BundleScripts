import os
import re
import pyUtils

backdoorRegexRepo = {
						".jsp"	:	re.compile(r'\W(new Socket|new ServerSocket|\.exec\s*\(|\.command\s*\(|getSystemJavaCompiler\s*\(|defineClass\s*\(|URLClassLoader\s*\(|ProcessBuilder\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".java"	:	re.compile(r'\W(new Socket|new ServerSocket|\.exec\s*\(|\.command\s*\(|getSystemJavaCompiler\s*\(|defineClass\s*\(|URLClassLoader\s*\(|ProcessBuilder\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".inc"	:	re.compile(r'\W(new Socket|new ServerSocket|\.exec\s*\(|\.command\s*\(|getSystemJavaCompiler\s*\(|defineClass\s*\(|URLClassLoader\s*\(|ProcessBuilder\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".c"	:	re.compile(r'\W(system\s*\(|execvp\s*\(|execv\s*\(|execlp\s*\(|execl\s*\(|execvpe\s*\(|execle\s*\(|connect\s*\(|sendto\s*\(|bind\s*\(|recvfrom\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".cc"	:	re.compile(r'\W(system\s*\(|execvp\s*\(|execv\s*\(|execlp\s*\(|execl\s*\(|execvpe\s*\(|execle\s*\(|connect\s*\(|sendto\s*\(|bind\s*\(|recvfrom\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".h"	:	re.compile(r'\W(system\s*\(|execvp\s*\(|execv\s*\(|execlp\s*\(|execl\s*\(|execvpe\s*\(|execle\s*\(|connect\s*\(|sendto\s*\(|bind\s*\(|recvfrom\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".pl"	:	re.compile(r'\W(exec\s*[\(\{\[\'\"\`]\W|system\s*[\(\{\[\'\"\`]\W|\W=\s*`\W`|open\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".pm"	:	re.compile(r'\W(exec\s*[\(\{\[\'\"\`]\W|system\s*[\(\{\[\'\"\`]\W|\W=\s*`\W`|open\s*\(|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".asp"	:	re.compile(r'\W(Wscript\.Shell|Process\.Start|new Socket|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".aspx"	:	re.compile(r'\W(Wscript\.Shell|Process\.Start|new Socket|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".sql"	:	re.compile(r'\W(host\s*\(|dbms_pipe|DBMS_SCHEDULER.create_program.*EXECUTABLE|java\.lang\.RuntimePermission|DBMS_JAVA|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE),
						".pck"	:	re.compile(r'\W(host\s*\(|dbms_pipe|DBMS_scheduler.create_program.*EXECUTABLE|java\.lang\.RuntimePermission|DBMS_JAVA|/bin/sh|cmd\.exe)\W',re.MULTILINE|re.IGNORECASE)
			}

skippedAbruptly = {}

def findPossibleBackdoor(filename, outFile):
	ext = os.path.splitext(filename)[1].lower()
	if ext in list(backdoorRegexRepo.keys()):
		with open (filename, "r", encoding ="utf8", errors="replace") as theFile:
			print("[i] Testing for possible backdoor at " + filename)
			filecontent = theFile.read()
			backdoors = re.findall(backdoorRegexRepo[ext],filecontent)
			for backdoor in backdoors:
				print("[X] found possible backdoor in " + filename)
				listOfColumns = []
				listOfColumns.append(filename)
				listOfColumns.append(backdoor)
				listOfColumns.append(ext)
				pyUtils.writeToCSV(listOfColumns,outFile)

def findPossibleBackdoors(directory, outDirectory):
	global skippedAbruptly
	pyUtils.writeToCSV(["Filename","Possible command execution at","Extension"],outDirectory+"/possible_backdoors_"+outDirectory+".csv")
	for root, subdirs, files in os.walk(directory):
		for file in os.listdir(root):
			filename = os.path.join(root, file)
			if os.path.isdir(filename):
				pass
			elif(pyUtils.is_hidden(filename)):
				pass
			else:
				try:
					findPossibleBackdoor(filename, outDirectory+"/possible_backdoors_"+outDirectory+".csv")
				except KeyboardInterrupt:
					key_choice = input("[W] Press C(Continue skipping current file)/s(Skip current analysis/q(quit scanner)> ")
					if key_choice.lower() == 'c':
						skippedAbruptly["findPossibleBackdoor "+filename] = "KeyboardInterrupt - skipped file"
						pass
					elif key_choice.lower() == 's':
						skippedAbruptly["findPossibleBackdoor "+filename] = "KeyboardInterrupt - skipped analysis"
						return skippedAbruptly
					elif key_choice.lower() == 'q':
						skippedAbruptly["findPossibleBackdoor "+filename] = "KeyboardInterrupt - quit scan"
						raise
					else:
						skippedAbruptly["findPossibleBackdoor "+filename] = "KeyboardInterrupt - skipped file"
						pass
				except Exception as e:
					print("[X] findPossibleBackdoor: Some error occurred: "+ filename)
					skippedAbruptly["findPossibleBackdoor "+filename] = str(e)
	return skippedAbruptly

if __name__ == "__main__":
	directory = input("Enter path to directory: \n> ")
	findPossibleBackdoors(directory, ".")